package com.xebia.xupTool.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xebia.xupTool.entity.CheckEntity;


public interface CheckRepository extends JpaRepository<CheckEntity, Long>{
 
	List<CheckEntity> findAllByNameOrFrequence(String name, Long frequence);
}
