package com.xebia.xupTool.service;

import java.util.List;

import com.xebia.xupTool.model.CheckModel;
import com.xebia.xupTool.model.RequestModel;

public interface CheckService {

	
	List<CheckModel> getAllCheckData();
	
	void saveCheckData();
	
	List<CheckModel> getAllCheckDataByNameorInterval(RequestModel model);
}
