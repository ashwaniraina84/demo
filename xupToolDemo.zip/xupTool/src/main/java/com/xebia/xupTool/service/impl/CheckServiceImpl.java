package com.xebia.xupTool.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xebia.xupTool.dao.CheckDao;
import com.xebia.xupTool.entity.CheckEntity;
import com.xebia.xupTool.model.CheckModel;
import com.xebia.xupTool.model.RequestModel;
import com.xebia.xupTool.service.CheckService;


@Service
public class CheckServiceImpl implements CheckService {

	
	@Autowired
	private CheckDao checkDao;
	
	@Override
	public List<CheckModel> getAllCheckData() {
		
		List<CheckEntity> list=checkDao.getAllCheckData();
		List<CheckModel> checkModelList= new ArrayList<>();
		list.forEach(entity->{
			CheckModel model= new CheckModel();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setWebsiteURL(entity.getWebsiteURL());
			model.setFrequence(entity.getFrequence());
			model.setActiveStatus(entity.getActiveStatus());
			checkModelList.add(model);
		});
		return checkModelList;
	}

	@Override
	public void saveCheckData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<CheckModel> getAllCheckDataByNameorInterval(RequestModel model) {
		
		CheckEntity checkEntity= new CheckEntity();
		checkEntity.setName(model.getName());
		checkEntity.setFrequence(model.getInterval());
		List<CheckEntity> list= checkDao.getAllCheckDataByNameorInterval(checkEntity);
		return null;
	}

}
