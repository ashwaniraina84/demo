package com.xebia.xupTool.model;

public class RequestModel {

	 private String name;
	 
	 private Long interval;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getInterval() {
		return interval;
	}

	public void setInterval(Long interval) {
		this.interval = interval;
	}
	 
}
