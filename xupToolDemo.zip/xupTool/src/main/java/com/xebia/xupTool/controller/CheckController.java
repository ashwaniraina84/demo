package com.xebia.xupTool.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.xebia.xupTool.model.CheckModel;
import com.xebia.xupTool.model.RequestModel;
import com.xebia.xupTool.service.CheckService;

@RestController
@RequestMapping("/v1")
public class CheckController {

	
	@Autowired 
	private CheckService service;
	
	@Autowired 
	private Gson gson;
	
	@RequestMapping(path="/checks", method=RequestMethod.GET, produces="application/json")
	public List<CheckModel> getCheckModelList()
	{
		return service.getAllCheckData();
	}
	
	@RequestMapping(path="/checks/search", method=RequestMethod.GET, produces="application/json")
	public List<CheckModel> getCheckModelListByNameOrInterval(@RequestBody RequestModel model)
	{
		return service.getAllCheckDataByNameorInterval(model);
	}
}
