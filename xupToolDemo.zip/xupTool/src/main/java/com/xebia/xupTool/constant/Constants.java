package com.xebia.xupTool.constant;

public class Constants {

}
