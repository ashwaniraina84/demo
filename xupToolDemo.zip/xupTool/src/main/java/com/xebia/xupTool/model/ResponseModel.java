package com.xebia.xupTool.model;

public class ResponseModel {

}
