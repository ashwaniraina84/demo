package com.xebia.xupTool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XupToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(XupToolApplication.class, args);
		System.out.println("Application Started..");
	}

}
