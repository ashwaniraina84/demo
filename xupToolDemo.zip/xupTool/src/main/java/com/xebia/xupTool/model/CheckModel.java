package com.xebia.xupTool.model;

public class CheckModel {
	
	
	private Long id;
	
	
	private String name;
	
	
	private String websiteURL;
	

	private Long frequence;
	
	
	private Character activeStatus;


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getWebsiteURL() {
		return websiteURL;
	}


	public void setWebsiteURL(String websiteURL) {
		this.websiteURL = websiteURL;
	}


	public Long getFrequence() {
		return frequence;
	}


	public void setFrequence(Long frequence) {
		this.frequence = frequence;
	}


	public Character getActiveStatus() {
		return activeStatus;
	}


	public void setActiveStatus(Character activeStatus) {
		this.activeStatus = activeStatus;
	}
	
	

}
