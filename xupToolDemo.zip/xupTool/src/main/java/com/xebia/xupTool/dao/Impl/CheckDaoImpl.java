package com.xebia.xupTool.dao.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.xebia.xupTool.dao.CheckDao;
import com.xebia.xupTool.entity.CheckEntity;
import com.xebia.xupTool.repository.CheckRepository;

@Transactional
@Repository
public class CheckDaoImpl implements CheckDao {

	
  @Autowired
  private CheckRepository checkRepository;
	
	@Override
	public List<CheckEntity> getAllCheckData() {
		// TODO Auto-generated method stub
		return checkRepository.findAll();
	}

	@Override
	public void saveCheckData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<CheckEntity> getAllCheckDataByNameorInterval(CheckEntity checkEntity) {
		// TODO Auto-generated method stub
		return checkRepository.findAllByNameOrFrequence(checkEntity.getName(), checkEntity.getFrequence());
	}

}
