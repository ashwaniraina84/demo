package com.xebia.xupTool.dao;

import java.util.List;

import com.xebia.xupTool.entity.CheckEntity;

public interface CheckDao {

	
	List<CheckEntity> getAllCheckData();
	
	void saveCheckData();
	
	List<CheckEntity> getAllCheckDataByNameorInterval(CheckEntity checkEntity);
	
	
}
